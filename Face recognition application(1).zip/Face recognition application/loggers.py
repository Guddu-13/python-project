"""
Copyright (C) 2018, AIMLedge Pte, Ltd.
All rights reserved.

"""
import logging

face_recognition_app_logger = logging.getLogger('Face_Rec_App')